#! /bin/sh

#This script is to install agent_linux
#This script now is located /soc_c/agent/agent_linux/agent_control/remove.sh
#This script is located /agent_linux/remove.sh at last.
#########################remove#######################
#This script is to remove all of agent_linux

#---------------environment variable---------------#
NAME=agent_linux

#---------------remove start end---------------#
rm_start() 
{
	echo "********************************************************************" 
	echo "*LINUX AGENT is removing ,please wait ... "
}
rm_end() 
{ 
	echo "*Removing $NAME	 			[ OK ]"
	echo "*LINUX AGENT already removed ."
	echo "********************************************************************" 
}

#--------------remove project---------------#
rm_project()
{
	killall agent_v2 2>/dev/null
	killall GetUserIfo 2>/dev/null
	killall get_all_log 2>/dev/null
	killall GetHostInfo 2>/dev/null
	killall linux_server 2>/dev/null
	killall monitor_linux 2>/dev/null
	killall instruction_Ifo 2>/dev/null
	killall Reboot_Shundown 2>/dev/null
	
	echo "*Shutting down $NAME           		[ OK ]"
		
	cd ..
	cd ..
	rm ./agent_linux -r
}

#--------------remove----------------#
#We must stop the process of soc,though some process was not running just now
rm_box()
{
	rm_start
	rm_project	
	rm_end
}
#------------rm ok------------------#
rm_box 

exit 0

