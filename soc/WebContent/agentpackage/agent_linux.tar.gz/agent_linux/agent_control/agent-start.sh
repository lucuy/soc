#! /bin/sh

#This script is to install agent_linux
#This script now is located /soc_c/agent/agent_linux/agent_control/start.sh
#This script is located /agent_linux/agent_control/start.sh at last.


#---------------------enviroment variable---------------#
NAME=linux_agent

#-------------------start stop linux agent--------------#
start_linux_agent()
{
	#start agent
	cd ../agent/
	./agent_v2 ../soc.conf &

	echo "*Start $NAME			[ OK ]"
}

stop_linux_agent()
{
	killall agent_v2 2>/dev/null
	killall GetUserIfo 2>/dev/null
	killall get_all_log 2>/dev/null
	killall GetHostInfo 2>/dev/null
	killall linux_server 2>/dev/null
	killall monitor_linux 2>/dev/null
	killall instruction_Ifo 2>/dev/null
	killall Reboot_Shundown 2>/dev/null
	
	echo "*Stop old $NAME			[ OK ]"
}

#-----------------check linux agent if or not complete--------------#
check_dir()
{
	if [ -f ../agent/agent_v2 \
		-a ../functions/script/get_all_log \
		-a ../functions/script/GetUserIfo \
		-a ../functions/script/instruction_Ifo \
		-a ../functions/script/monitor_linux \
		-a ../functions/script/Reboot_Shundown ]
	then
		echo -n
	else
		echo "*AGETN_LINUX is not complete ,and has exit ."
		echo "*Please acquire a new agent_linux.tar.gz to restart."
		echo "******************************************************************"
		exit 1
	fi
}

#-------------------chmod +x--------------#
chmod_file()
{
	chmod 777 ../agent/agent_v2
	chmod 777 ../functions/script/*
}

#-------------------restart run agent_linux project--------------#
start_run_project()
{
	echo "******************************************************************"
	echo "*LINUX AGENT is starting , please wait ..."
	check_dir
	stop_linux_agent
	chmod_file
	start_linux_agent
	echo "*LINUX AGENT already start ."
	echo "******************************************************************"
}

start_run_project

exit 0
