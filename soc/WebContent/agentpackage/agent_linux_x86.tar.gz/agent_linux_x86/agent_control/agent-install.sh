#! /bin/sh

#agent_install 为agent客户端的安装脚本,执行一次
#install程序流程设计：
#	1.检测程序完整新ag
#	2.更改所有的执行程序的权限
#	3.获取本机所有ip->用户选择ip->写入配置文件
#	4.用户输入box的ip->写入配置文件
#	5.设置开机自启


#--------------------------------------------------------------#
#1.检测程序完整新
check_dir()
{
	if [ -f ./../agent/agent_v2 \
		-a ./../functions/script/get_all_log \
		-a ./../functions/script/GetUserIfo \
		-a ./../functions/script/instruction_Ifo \
		-a ./../functions/script/monitor_linux \
		-a ./../functions/script/Reboot_Shundown ]
	then
		echo "*AGETN_LINUX_X86 is complete ,and will run normally ."
	else
		echo "*AGETN_LINUX_X86 is not complete ,and has exit ."
		echo "*Please acquire a new agent_linux_x86.tar.gz to restart ."
		echo "**********************************************"
		exit 1
	fi
}

#2.更改所有的执行程序的权限
chmod_file()
{
	chmod 777 ./inter
	chmod 777 ./agent-stop.sh
	chmod 777 ./agent-start.sh
	chmod 777 ./agent-remove.sh
	chmod 777 ./local_ip_inter
	chmod 777 ./../agent/agent_v2
	chmod 777 ./../agent/rc.local
	chmod 777 ./../functions/script/* 
}

#3.获取本机所有ip->用户选择ip->写入配置文件
set_host_ip()
{
	./local_ip_inter ./../soc.conf
}

#4.用户输入box的ip->写入配置文件
set_box_ip()
{
	./inter ./../soc.conf
	echo "*Edit the soc configure file ok ."
}

#5.设置开机自启动agent程序
set_start_reboot()
{
	#get local rc.local
	if [ ! -f /etc/rc.local ]
	then
		cp ../agent/rc.local /etc/
	fi
	
	if [ -f /etc/rc.local ]
	then
		AGENT_INSTALL_LOG=`cat /etc/rc.local |grep "agent_v2" |wc -l`
		if [ $AGENT_INSTALL_LOG -eq 0 ]
		then
			echo "*System first install agent ."
			MYPATH=`pwd`
			sed  -i "/#!\/bin\/sh/a \
#This is agent reboot script \n \
if [ -f \\${MYPATH}/../agent/agent_v2 ]\n \
then\n \
	cd \\${MYPATH}/../agent/\n \
	chmod 777 \\${MYPATH}/../agent/agent_v2\n \
	./agent_v2 ../soc.conf\n \
fi\n" /etc/rc.local
		fi
		
		chmod 777 /etc/rc.local
		echo "*Set agent reboot at startup ok ."
	fi
}

#--------------------------------------------------------------#
install_agent()
{
	echo "**********************************************"
	echo "*Agent install start ,please wait ..."
	check_dir
	chmod_file
	set_host_ip
	set_box_ip
	set_start_reboot
	echo "*Agent install complete ."
	echo "**********************************************"
}

install_agent

exit 0
