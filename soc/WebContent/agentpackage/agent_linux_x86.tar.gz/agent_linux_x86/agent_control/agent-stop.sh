#! /bin/sh

#This script is to stop agent_linux_x86
#This script now is located /soc_c/agent/agent_linux_x86/agent_control/stop.sh
#This script is located /agent_linux_x86/agent_control/stop.sh at last.


#-------------------------global variable---------------#
NAME=linux_agent_x86

#-------------------stop linux agent--------------#
stop_linux_agent()
{
	killall agent_v2 2>/dev/null
	killall GetUserIfo 2>/dev/null
	killall get_all_log 2>/dev/null
	killall GetHostInfo 2>/dev/null
	killall linux_server 2>/dev/null
	killall monitor_linux 2>/dev/null
	killall instruction_Ifo 2>/dev/null
	killall Reboot_Shundown 2>/dev/null
	echo "*Stop $NAME			[ OK ]"
}

#-------------------stop run agent_linux project--------------#
stop_run_project()
{
	echo "******************************************************************"
	echo "*LINUX AGENT is stopping ,please wait ..."
	stop_linux_agent
	echo "*LINUX AGENT already stoped ."
	echo "******************************************************************"
}

stop_run_project
exit 0
